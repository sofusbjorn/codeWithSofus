Koden kan køres med følgende steps:

$ fsharpc -a rotate.fsi rotate.fs && fsharpc -r rotate.dll game.fsx && mono game.exe