Rapporten oversættes fra .tex til .pdf ved blot at køre 'pdflatex' i terminalen i det rette directory.

Desuden oversættes koden ved at køre enten 'fsharpi 2i1.fsx' i det rette dir
	eller ved at køre 'fsharpc 2i1.fsx' og derefter 'mono 2i1.exe'.