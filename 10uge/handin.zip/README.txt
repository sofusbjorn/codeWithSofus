$ fsharpc -a img_util.fsi img_util.fs
$ fsharpc -r img_util.dll 8i0.fsx && mono 8i0.exe